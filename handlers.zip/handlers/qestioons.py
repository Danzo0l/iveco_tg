import os
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram import types, Dispatcher
from aiogram.dispatcher import FSMContext
from settings import ADMINS
from utils.reporter import export_users_to_excel
from questions import questions
from keyboards.main_keyboard import main_keyboard


class RegistrationState(StatesGroup):
    start = State()
    name = State()
    username = State()
    age = State()
    skill_sale = State()


async def admin_init(message: types.Message, state: FSMContext):
    if message.from_user.username in ADMINS:
        await state.finish()
        await export_users_to_excel()
        base_path = os.path.dirname(os.path.abspath(__file__))  # Получение пути к текущему файлу
        file_path = os.path.join(base_path, "../static/report.xlsx")  # Формирование полного пути к файлу
        if os.path.exists(file_path):  # Проверка наличия файла
            with open(file_path, 'rb') as file:
                await message.answer_document(file)
        else:
            await message.answer('Файл не найден')
    else:
        await message.answer('У вас нет прав администратора')


async def cmd_start(message: types.Message):
    await message.answer(questions["hello"]["text"], reply_markup=main_keyboard)
    await RegistrationState.start.set()


async def start_test(message: types.Message):
    if message.text == '🚀 Начать!':
        await message.answer(questions["name"]["text"])
        await RegistrationState.name.set()
    else:
        await message.answer('Некорректный ответ')


async def process_name(message: types.Message, state: FSMContext):
    first_name = message.text
    await state.update_data(name=first_name)
    await message.answer(questions["age"]["text"])
    await RegistrationState.age.set()


# @dp.message_handler(state=RegistrationState.AGE)
async def process_age(message: types.Message, state: FSMContext):
    age = message.text
    if age.isdigit():
        await state.update_data(age=age)
    # Получение всех ответов из состояния
        data = await state.get_data()
    # Вывод ответов
        await message.answer(questions["age"]["text"])
    else:
        await message.answer('Некорректный ответ')
    # Сброс состояния


# await state.finish()
# await state.reset_state(with_data=False)
def resister_handlers_start(dp: Dispatcher):
    dp.register_message_handler(admin_init, commands=['admin'], state='*')
    dp.register_message_handler(cmd_start, commands=['start'])
    dp.register_message_handler(start_test, state=RegistrationState.start)
    dp.register_message_handler(process_name, state=RegistrationState.name)
    dp.register_message_handler(process_age, state=RegistrationState.age)

