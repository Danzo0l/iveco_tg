from aiogram import types, Dispatcher
from keyboards.main_keyboard import main_keyboard
from settings import CONNECTION


async def help_main(message: types.Message):
    await message.answer_photo(
        photo=types.InputFile('./img/broker.jpg'),
        parse_mode=types.ParseMode.HTML,
        caption=
        'Это бот для сотрудников Совкоминвест. Доступ сюда ограничен.\n\n'
        '<b>Команды</b>\n'
        '/help - <i>открывает инструкцию с описанием всех команд и возможностей инструмента</i>\n'
        '/start - <i>перезапускает бота, в некоторых режимах используется для выхода в главное меню</i>\n'
        '/admin - <i>используется для входа в меню администратора</i>\n\n'
        '<b>Главное меню</b>\n'
        'В главном меню 2 кнопки: \n'
        '⌨️  Разместить объявление <i>открывает форму для создания нового объявления,'
        'оно автоматически попадает в тематическую группу.</i>\n'
        '🔍  Поиск по базе <i>предоставляет возможность быстро найти ранее добавленное объявление.</i>\n\n'
        '<b>Возможности</b>\n'
        '💡 Можно быстро найти объявление по ключевым словам, бот предложит все совпадения\n'
        '📑  Добавление объявления производится в формате: Вопрос-Ответ, важно отвечать строго на вопросы\n'
        '🗑  Удаление объявления производится по id - если не помните id объявления,\n'
        'то через поиск можно найти само объявление и уже после удалить',
        reply_markup=main_keyboard)


def resister_handlers_start(dp: Dispatcher):
    dp.register_message_handler(help_main, commands=['help'])
